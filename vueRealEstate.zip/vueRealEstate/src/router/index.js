import Vue from 'vue'
import Router from 'vue-router'
//导入组件
import login from '@/components/user/login'
import forgetPassword from '@/components/user/forgetPassword'
import index from '@/components/index/index'
import examine from '@/components/companymanagement/examine'
import examinePass from '@/components/companymanagement/examinePass'
import examineNotPass from '@/components/companymanagement/examineNotPass'
import examineCheck from '@/components/companymanagement/examineCheck'
import breadcrumb from '@/components/shared/breadcrumb'

Vue.use(Router)

export default new Router({
    routes: [{
        path: '/',
        redirect: '/login'
    }, {
        path: '/login',
        name: 'login',
        component: login
    }, {
        path: '/forgetPassword',
        name: 'forgetPassword',
        component: forgetPassword
    }, {
        path: '/index',
        name: 'index',
        component: index,
        children: [{
            path: '/',
            redirect: '/index/examine'
        }, {
            path: '/index/examine',
            name: 'examine',
            component: examine
        }, {
            path: '/index/examinepass',
            name: 'examinePass',
            component: examinePass
        }, {
            path: '/index/examinenotpass',
            name: 'examineNotPass',
            component: examineNotPass
        }, {
            path: '/index/examinecheck',
            name: 'examinecheck',
            component: examineCheck
        }]
    }]
})