<template>
    <div id="login">
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" class="demo-ruleForm login-container">
            <h3 class="title">欢迎使用</h3>
            <el-form-item prop="account">
                <el-input v-model="ruleForm.account" type="text" placeholder="用户名"></el-input>
            </el-form-item>
            <el-form-item prop="password">
                <el-input v-model="ruleForm.password" type="password" placeholder="密码"></el-input>
            </el-form-item>
            <el-form-item style="width:100%;">
                <el-button :disabled="ruleForm.account==='' || ruleForm.password==='' " type="primary" style="width:100%;" @click="login()">登录</el-button>
                <!--<el-button @click.native.prevent="handleReset2">重置</el-button>-->
            </el-form-item>
            <el-form-item class="list">
                <el-col class="login-line" :span=12>
                    <span @click="Forget()">忘记密码</span>
                </el-col>
                <el-col class="login-register" :span=12>
                    <span>注册</span>
                </el-col>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
import md5 from "js-md5"; //导入md5加密
export default {
  data() {
    return {
      ruleForm: {
        account: "",
        password: ""
      },
      rules: {
        account: [{ required: true, message: "账号不能为空" }],
        password: [{ required: true, message: "密码不能为空" }]
      }
    };
  },
  name: "login",
  methods: {
    Forget() {
      this.$router.push({ path: "/forgetPassword" });
    },
    login() {
      let data = {
        Phone: this.ruleForm.account,
        Pwd: this.ruleForm.password
      };
      console.log(this.MD5(data.Pwd));
    //   this.$http.get(
    //     "xxx/xxx/xxx?User=" + data.Phone + "&password=" + data.Pwd
    //   );
    //   this.$http.post("xxx/xxx/xxx=", JSON.stringify(data));
      console.log(JSON.stringify(data));
      this.$router.push({ path: "/index" })
    }
  }
};
</script>

<style  scoped>
.login-container {
  -webkit-border-radius: 5px;
  border-radius: 5px;
  -moz-border-radius: 5px;
  background-clip: padding-box;
  margin: 180px auto;
  width: 350px;
  padding: 35px 35px 15px 35px;
  background: #fff;
  border: 1px solid #692c2c;
  box-shadow: 0 0 25px #cac6c6;
}
.title {
  margin: 0px auto 40px auto;
  text-align: center;
  color: #505458;
}
.list {
  color: #12b7f5;
  text-align: center;
}
span {
  cursor: pointer;
}
.login-line {
  height: 20px;
  border-right: 1px solid #d7d7d7;
  line-height: 20px;
}
.login-register {
  line-height: 20px;
}
</style>
