const httphead = { 'headers': { 'Content-Type': 'application/json', 'Accept': 'application/json;charset=utf-8' } }
const httpurl = '' //localStorage.getItem('http')
const webservicexml = (method, data) => {
    console.log('提交参数=====>' + method, data)
    let DATA = '<soapenv:Envelope xmlns:soapenv=\'http://schemas.xmlsoap.org/soap/envelope/\' xmlns:own=\'http://own.mamp.ophiux.com/\'>' +
        '<soapenv:Body>' +
        '<' + method + '>' +
        '<data>' +
        JSON.stringify(data) +
        '</data>' +
        '</' + method + '>' +
        '</soapenv:Body>' +
        '</soapenv:Envelope>'
    return DATA
}
const returndata = (data) => {
    data = data.replace(/&quot;/g, '"').replace(/<return>/g, '%').replace('</return>', '%')
    data = data.split('%')
    data = data[1]
    console.log(JSON.parse(data))
    return JSON.parse(data)
}
const getrandomstring = (data) => {


}

const md5 = (data) => {
    return this.MD5(data);
}

export default {
    httphead,
    httpurl
    //webservicexml,
    //returndata
}