<template>
  <div id="computerset">
  	
  </div>
</template>

<script>
	export default{
		name:'computerset',
		data(){
			return{
				
			}
		}
	}
</script>

<style>
  	
</style>