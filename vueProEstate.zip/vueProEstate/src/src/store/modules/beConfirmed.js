const state={
	sels:""
}

const mutations={
	addsels(sate,payload){
		state.sels=payload
	}
}

export default{
  		state,
  		mutations
}
