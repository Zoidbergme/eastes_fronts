const state={
	ele:"全部"
}
const mutations={
	change(state,payload){
		state.ele=payload;	
	}
}

export default{
	state,
	mutations
}
