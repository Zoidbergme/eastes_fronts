const state={
	showForM:''
}
const mutations={
	showForm(state,payload){
		state.showForM=state.showForm
	}
}


export default{
	state,
	mutations
}
