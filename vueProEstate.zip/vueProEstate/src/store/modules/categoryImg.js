import $http from 'axios'
import Rooturl from '../../../static/Rooturl'
import qs from 'qs'


const state={
	
}


const mutations={
	
}


const actions={
	
}


export default{
	state,
	mutations,
	actions
}
