const state={
	sels:"",
	showForm:'visit'
}

const mutations={
	CkPayDeTailaddsels(sate,payload){
		state.sels=payload
	},
	showForm(state,payload){
		state.showForM=payload
	}
}
const acctions={
	
}
export default{
  		state,
  		mutations,
  		acctions
}
