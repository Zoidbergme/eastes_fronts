const state={
	
}

const getter={
	
}

const mutations={
	
}

const actions={
	
}



export default {
	state,
	getter,
	actions,
	mutations    
}
