const state={
	sels:""
}

const mutations={
	AddApply(sate,payload){
		state.sels=payload
	}
}

export default{
  		state,
  		mutations
}
